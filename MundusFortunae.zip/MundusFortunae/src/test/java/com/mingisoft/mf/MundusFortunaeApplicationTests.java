package com.mingisoft.mf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MundusFortunaeApplicationTests {

	@Test
	void contextLoads() {
	}

}
