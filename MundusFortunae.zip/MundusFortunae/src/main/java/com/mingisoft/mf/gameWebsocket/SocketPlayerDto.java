package com.mingisoft.mf.gameWebsocket;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocketPlayerDto {

  private Long roomSeq;
  private String role;
  private int playerSeq;
  private String nickname;
  private int gameScore;
  
}
