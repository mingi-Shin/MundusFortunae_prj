package com.mingisoft.mf.project2;

public class Project2RoomDto {

  private Long roomSeq;
  
}
